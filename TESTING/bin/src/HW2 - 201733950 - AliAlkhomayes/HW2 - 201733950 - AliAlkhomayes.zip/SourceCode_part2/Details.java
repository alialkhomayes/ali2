package fapp;

public interface Details {
    String showDetails();
}
